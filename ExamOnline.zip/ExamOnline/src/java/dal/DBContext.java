package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

//public class DBContext {
//
//    public Connection connection;
//
//    public DBContext() {
//        try {
//            //Change the username password and url to connect your own database
//            // We get these information from environment variable so that it 
//            // can be changed without recompiling our code
//            String username = System.getenv("CSUSERNAME");
//            String password = System.getenv("CSPASSWORD");
//            String url = System.getenv("CS");
//
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Properties properties = new Properties();
//            properties.setProperty("user", username);
//            properties.setProperty("password", password);
//            properties.setProperty("sendTimeAsDatetime", "false"); // Set sendTimeAsDatetime to false
//            connection = DriverManager.getConnection(url, properties);
//        } catch (ClassNotFoundException | SQLException ex) {
//            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//
//}

public class DBContext {

    protected Connection connection;

    public DBContext() {
        //@Students: You are allowed to edit user, pass, url variables to fit 
        //your system configuration
        //You can also add more methods for Database Interaction tasks. 
        //But we recommend you to do it in another class
        // For example : StudentDBContext extends DBContext , 
        //where StudentDBContext is located in dal package, 
        try {
            String user = "sa";
            String pass = "123";
            String url = "jdbc:sqlserver://localhost\\SQLEXPRESS:1433;databaseName=COC_CHAM_HOC";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
